package com.alibaba.druid.util;

import junit.framework.TestCase;

/**
 * Created by wenshao on 16/07/2017.
 */
public class DropTables extends TestCase {

}
