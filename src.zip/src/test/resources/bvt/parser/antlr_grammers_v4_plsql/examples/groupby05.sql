select * from x
group by grouping sets
( ((a),b), ((a),b) )

