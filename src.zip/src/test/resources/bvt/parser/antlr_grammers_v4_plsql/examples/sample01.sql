select * from 
(
select 1 as c1 from "sys"."obj$" sample block (14.285714 , 1) seed (1) "o"
) samplesub
