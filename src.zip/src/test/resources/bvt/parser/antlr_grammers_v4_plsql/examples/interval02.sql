select interval '42' day from dual
