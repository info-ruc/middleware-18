select * from dual order by a nulls first,  b nulls last
