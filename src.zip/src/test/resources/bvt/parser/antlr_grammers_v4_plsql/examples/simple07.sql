select * from dual for update
of dual

