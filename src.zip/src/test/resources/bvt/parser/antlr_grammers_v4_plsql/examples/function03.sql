select trim(both from con.ke)
from dual


