-- com1
select * /*
com2 */
from dual -- com3
