select * from dual order by m.year, m.title, f(a)
