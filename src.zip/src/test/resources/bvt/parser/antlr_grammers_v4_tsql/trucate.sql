TRUNCATE TABLE HumanResources.JobCandidate;  
GO  
TRUNCATE TABLE PartitionTable1
WITH (PARTITIONS (2, 4, 6 TO 8));
GO

