CREATE SYNONYM MyProduct  
FOR AdventureWorks2012.Production.Product;  
GO  
CREATE SYNONYM MyEmployee FOR Server_Remote.AdventureWorks2012.HumanResources.Employee;  
GO 
CREATE SYNONYM dbo.CorrectOrder
FOR dbo.OrderDozen;
GO
