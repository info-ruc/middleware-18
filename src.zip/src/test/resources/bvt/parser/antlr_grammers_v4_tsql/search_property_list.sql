CREATE SEARCH PROPERTY LIST DocumentPropertyList;
CREATE SEARCH PROPERTY LIST JobCandidateProperties
FROM AdventureWorks2012.DocumentPropertyList;


