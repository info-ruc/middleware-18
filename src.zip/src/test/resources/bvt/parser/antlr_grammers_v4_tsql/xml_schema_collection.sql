CREATE XML SCHEMA COLLECTION MyCollection AS @MySchemaCollection 
